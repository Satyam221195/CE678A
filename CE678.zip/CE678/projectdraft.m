data = dlmread('NGS_GRAVD_Block_CN04_Gravity_Data_BETA1.txt', ' ');

% Now 'data' contains your data with 6 columns
% You can access individual columns like this:
flightline = data(:, 1);  % Column 1
nominal_altitude = data(:, 2);  % Column 2
latitude = data(:, 5); % Column 3
disp(length(latitude));
longitude = data(:, 7);  % Column 4
disp(length(longitude));
altitude_for_analysis = data(:, 8);  % Column 5
gravity_data = data(:, 9);  % Column 6
disp(length(data));
disp(length(gravity_data));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 3 :Calculate free air anomaly (medium wavelength).
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Constants
a = 6378137; % Semi-major axis of the Earth (in meters)
b = 6356752; % Semi-minor axis of the Earth (in meters)
gamma_a = 9.7803267714; % Normal gravity at the equator (m/s^2)
gamma_b = 9.8321863685; % Normal gravity at the poles (m/s^2)

% Latitude in radians (assuming you already have latitude data)
phi = deg2rad(latitude); % Convert latitude from degrees to radians


% Calculate normal gravity (γ) using the Somigliana-Pizzetti formula
#gamma = (a * gamma_a * cos(phi).^2 + b * gamma_b * sin(phi).^2) / sqrt(a * cos(phi).^2 + b * sin(phi).^2);

% Calculate normal gravity (γ)
a_cos2_phi = a * (cos(phi)).^2;
b_sin2_phi = b * (sin(phi)).^2;
sqrt_term = sqrt(a^2* (cos(phi)).^2 + b^2*(sin(phi)).^2);
gamma = (( gamma_a * a_cos2_phi + gamma_b * b_sin2_phi)./ sqrt_term)*10^5;% in mGal



% Calculate the free-air anomaly (Δg)

del_g_Free_air = +0.3086*( altitude_for_analysis); %in mgal
observed_gravity = gravity_data ;% Replace with your observed gravity data
delta_g = (observed_gravity +del_g_Free_air) - gamma;
% fprintf('Free Air Anomaly:%d \n',delta_g);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 4 (a):Calculate delta GGM.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
data_ggm = dlmread('GGM05C_new.txt', ' ');

% Now 'data' contains our data with 10 and 11 columns
Gravity_anamoly_GGM = data_ggm(:,10) + data_ggm(:,11); % Column


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 4 (b):Reduced Gravity Anomaly Δgs&mw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%reduced gravity anomaly Δgs&mw
reduced_gravity_anamoly = delta_g - Gravity_anamoly_GGM;
%fprintf('Reduced Gravity Anamaly is: %d\n', reduced_gravity_anamoly);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 5 :correction to account for the gravitational attraction of the atmosphere
% Δg atms&mw
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

H = altitude_for_analysis;
x1=0.871 - 1.0298e-4 * H;
x2=5.3105e-9 * H.^2;
x3=2.1642e-13 * H.^3 ;
x4=9.5246e-18 * H.^4;
x5=2.2411e-22 * H.^5;
#del_g_atm = 0.871 - 1.0298e-4 * H + 5.3105e-9 * H^2 - 2.1642e-13 * H^3 + 9.5246e-18 * H^4 - 2.2411e-22 * H^5;
del_g_atm =x1+x2-x3+x4-x5;
delta_reduced_gravity_anamoly_atm = reduced_gravity_anamoly - del_g_atm;
%fprintf('Correction to account for the gravitational attraction of the atmosphere is: %d\n', delta_reduced_gravity_anamoly_atm(1:10));
disp(length(delta_reduced_gravity_anamoly_atm));

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 :Convert the gravity anomaly delta_reduced_gravity_anamoly_atm data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%
lon = longitude;  % Longitude of data points
lat = latitude;  % Latitude of data points
gravity_anomaly1 = delta_reduced_gravity_anamoly_atm ;  % Gravity anomaly values at data points
disp(length(gravity_anomaly1));
grid_resolution = 0.1;  % Set the desired grid resolution (adjust as needed)

% Define the grid where you want to interpolate
lon_grid = linspace(min(lon), max(lon), round((max(lon) - min(lon)) / grid_resolution));
lat_grid = linspace(min(lat), max(lat), round((max(lat) - min(lat)) / grid_resolution));

[lon_grid, lat_grid] = meshgrid(lon_grid, lat_grid);


% Interpolate the data onto the grid
grid_gravity_anomaly = griddata(lon, lat, gravity_anomaly1, lon_grid, lat_grid, 'linear');
grid_gravity_anomaly(isnan(grid_gravity_anomaly)) = 0;
% Plot the grid
figure(1);
contourf(lon_grid, lat_grid, grid_gravity_anomaly);
colormap('jet');
colorbar;
title('Correction for the gravitational attraction of the atmosphere (Δg atms&mw)','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);
%%%%%%%%%%%%%%%%%%%%%%%%%%

% step 6 (A):Convert the Normal Gravity (Gamma) data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_gamma = griddata(lon, lat, gamma , lon_grid, lat_grid, 'linear');

% Plot the grid
figure(2);
contour(lon_grid, lat_grid, grid_gamma);
colormap('jet');
colorbar;
title(' Normal Gravity (γ = Gamma)','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 (B):Convert the Free Air Anomaly delta g data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_free_air_anomaly = griddata(lon, lat, delta_g , lon_grid, lat_grid, 'linear');
grid_free_air_anomaly(isnan(grid_free_air_anomaly)) = 0;
% Plot the grid
figure(3);
contourf(lon_grid, lat_grid, grid_free_air_anomaly);
colormap('jet');
colorbar;
title('Free Air Anomaly (Δg)','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 (C):Convert the Reduced Gravity Anamoly data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_reduced_gravity_anomaly = griddata(lon, lat, reduced_gravity_anamoly , lon_grid, lat_grid, 'linear');
grid_reduced_gravity_anomaly(isnan(grid_reduced_gravity_anomaly)) = 0;
% Plot the grid
figure(4);
contourf(lon_grid, lat_grid, grid_reduced_gravity_anomaly );
colormap('jet');
colorbar;
title('Reduced Gravity Anamoly Δgs&mw','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 (D):Convert the Gravity Anamoly GGM data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
grid_Gravity_anamoly_GGM_anomaly = griddata(lon, lat, Gravity_anamoly_GGM ,lon_grid, lat_grid, 'linear');
grid_Gravity_anamoly_GGM_anomaly(isnan(grid_Gravity_anamoly_GGM_anomaly)) = 0;
% Plot the grid
figure(5);
contourf(lon_grid, lat_grid, grid_Gravity_anamoly_GGM_anomaly );
colormap('jet');
colorbar;
title('Long-wavelength Gravity Anamoly (ΔgGGM)','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 (E):Convert the g observed data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
gravity_data = data(:, 9);
grid_gravity_data = griddata(lon, lat, gravity_data ,lon_grid, lat_grid, 'linear');

% Plot the grid
figure(6);
contour(lon_grid, lat_grid, grid_gravity_data );
colormap('jet');
colorbar;
title('g observed','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 (F):Convert the + δgFree air data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
del_g_Free_air = +0.3086*( altitude_for_analysis); %in mgal
grid_del_g_Free_air = griddata(lon, lat, del_g_Free_air ,lon_grid, lat_grid, 'linear');
% Plot the grid
figure(7);
contour(lon_grid, lat_grid, grid_del_g_Free_air );
colormap('jet');
colorbar;
title('δg Free air','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% step 6 (G):Convert the δgatm data points into a grid.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
del_g_atm =x1+x2-x3+x4-x5;
grid_del_g_atm = griddata(lon, lat, del_g_atm ,lon_grid, lat_grid, 'linear');
% Plot the grid
figure(8);
contour(lon_grid, lat_grid, grid_del_g_atm );
colormap('jet');
colorbar;
title('δg atmosphere','FontSize', 20, 'FontWeight', 'bold');
xlabel('Longitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel('Latitude (degrees)', 'FontSize', 14, 'FontWeight', 'bold');
ylabel(colorbar, 'Units (mGal)', 'FontSize', 16, 'FontWeight', 'bold')
set(gca, 'FontSize', 20);
hcb = colorbar;
set(hcb, 'FontSize', 14);

