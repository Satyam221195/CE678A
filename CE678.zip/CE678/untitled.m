data_ggm = dlmread('deltaGGM05g.txt', ' ');

% Now 'data' contains your data with 6 columns
% You can access individual columns like this:
Gravity_anamoly_GGM = data_ggm(:,11);  % Column 5


%Gravity anomaly_GGM
%Gravity_anamoly_GGM = gshs_ptw(sc, lon, lat, r, R, 'GM', GM, 'max_lm', max_lm, 'quant', 'dg','sub_WGS84',false, 'waitbar', false);
fprintf('Gravity Anomaly GGM is: %.5f\n', Gravity_anamoly_GGM(1:10));